from tkinter import*
from tkinter import ttk,messagebox
from PIL import Image,ImageTk
import pymysql
import re





class Register:
    def __init__(self,root):
        
        self.root=root
        self.root.title("Registration Form")
        self.root.geometry("1550x800+0+0")
        self.root.config(bg="white")

        img1=Image.open(r"images\carpool.jpg")
        img1=img1.resize((1550,800))
        self.photoimg1=ImageTk.PhotoImage(img1)

        

    

        lblimg=Label(self.root,image=self.photoimg1,bd=4,relief=RIDGE)
        lblimg.place(x=0,y=0,width=1550,height=800)

         

         


        frame1=Frame(self.root,bg="#4863A0")
        frame1.place(x=0,y=100,width=600,height=600)

         

        title=Label(frame1,text="Registration page",font=("times new roman",20,"bold"),bg="#4863A0",fg="black").place(x=50,y=30)


        
        f_name=Label(frame1,text="First Name",font=("times new roman",15,"bold"),bg="#4863A0",fg="black").place(x=50,y=100)
        self.txt_fname=Entry(frame1,font=("times new roman",15),bg="white")
        self.txt_fname.place(x=50,y=130,width=200)

        validate_fname=self.root.register(self.checkname)
        self.txt_fname.config(validate='key',validatecommand=(validate_fname,'%P'))

        l_name=Label(frame1,text="Last Name",font=("times new roman",15,"bold"),bg="#4863A0",fg="black").place(x=300,y=100)
        self.txt_lname=Entry(frame1,font=("times new roman",15),bg="white")
        self.txt_lname.place(x=300,y=130,width=200)

        validate_lname=self.root.register(self.checkname)
        self.txt_lname.config(validate='key',validatecommand=(validate_lname,'%P'))

         

        contact=Label(frame1,text="Contact Number",font=("times new roman",15,"bold"),bg="#4863A0",fg="black").place(x=50,y=170)
        self.txt_contact=Entry(frame1,font=("times new roman",15),bg="white")
        self.txt_contact.place(x=50,y=200,width=200)

        


        validate_contact=self.root.register(self.checkcontact)
        self.txt_contact.config(validate='key',validatecommand=(validate_contact,'%P'))

        


        email=Label(frame1,text="Username",font=("times new roman",15,"bold"),bg="#4863A0",fg="black").place(x=300,y=170)
        self.txt_email=Entry(frame1,font=("times new roman",15),bg="white")
        self.txt_email.place(x=300,y=200,width=200)



        validate_email=self.root.register(self.checkemail)
        self.txt_email.config(validate='key',validatecommand=(validate_email,'%P'))

        question=Label(frame1,text="Select Security Question",font=("times new roman",15,"bold"),bg="#4863A0",fg="black").place(x=50,y=240)
        self.cmb_quest=ttk.Combobox(frame1,font=("times new roman",13),state='readonly',justify=CENTER)
        self.cmb_quest['values']=("Select","Your First Pet Name","Your School Name","Your Favorite Food")
        self.cmb_quest.place(x=50,y=270,width=200)
        self.cmb_quest.current(0)
         

        answer=Label(frame1,text="Answer",font=("times new roman",15,"bold"),bg="#4863A0",fg="black").place(x=300,y=240)
        self.txt_answer=Entry(frame1,font=("times new roman",15),bg="white")
        self.txt_answer.place(x=300,y=270,width=200)
         

        password=Label(frame1,text="Password",font=("times new roman",15,"bold"),bg="#4863A0",fg="black").place(x=50,y=310)
        self.txt_password=Entry(frame1,font=("times new roman",15),bg="white")
        self.txt_password.place(x=50,y=340,width=200)

        cpassword=Label(frame1,text="Confirm Password",font=("times new roman",15,"bold"),bg="#4863A0",fg="black").place(x=300,y=310)
        self.txt_cpassword=Entry(frame1,show="*",font=("times new roman",15),bg="white")
        self.txt_cpassword.place(x=300,y=340,width=200)

         
        self.var_chk=IntVar()
        chk=Checkbutton(frame1,text="I Agree The Terms & Conditions",variable=self.var_chk,onvalue=1,offvalue=0,bg="#4863A0",font=("times new roman",12)).place(x=50,y=380)


        self.btn_img=ImageTk.PhotoImage(file=r"images\register.png")
        btn_register=Button(frame1,image=self.btn_img,bg="#4863A0",bd=0,cursor="hand2",command=self.register_data).place(x=50,y=420)
         

        self.btn_img1=ImageTk.PhotoImage(file=r"images\loginnow.png")
        btn1=Button(frame1,image=self.btn_img1,bg="#4863A0",bd=0,cursor="hand2",command=self.login_win).place(x=310,y=427)


    def checkname(self,name):
        if name.isalnum():
            return True
           
        else:
            messagebox.showerror('Invalid','Not Allowed '+name[-1])   


    def checkcontact(self,contact):
        if contact.isdigit():
            return True
        if len(str(contact))==0:
            return True
        else:
            messagebox.showerror("Invalid","Invalid Entry")   
            return False      


    def checkpassword(self,password):
        if len(password)<=21:
            if re.match("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z](?=.*[^a-bA-B0-9]))",password):
                return True
            else:
                messagebox.showwarning('Invalid','Enter valid password ')
                return False
        else:
            messagebox.showerror('Invalid',"Password is too short")
            return False


    def checkemail(self,email):
        if len(email)>7:
            if re.match("^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$",email):
                return True
            else:
                messagebox.showwarning("Alert","Invalid Email")   
                return False 
          

    def validations():
        if name.get=="":
            messagebox.showinfo("Alert","Enter your name ")    
        elif password.get=="":
            messagebox.showinfo("Alert","Enter Password ") 
        elif contact.get=="" or len(contact.get())!=10:
            messagebox.showinfo("Alert","Enter Valid Contact ")                 



    def login_win(self):
        self.root.destroy()
        import Login

    def invalid(self):
        invalid = Tk()
        invalid.title("Invalid Password")
        T = tk.Text(invalid, height=10, width=50)
        T.pack()
        T.insert(tk.END, """Invalid Password/n Include characters: numbers lowercase UPPERCASE Special Characters""")
 

    def clear(self):
        self.txt_fname.delete(0,END)
        self.txt_lname.delete(0,END)
        self.txt_contact.delete(0,END)
        self.txt_email.delete(0,END)
        self.cmb_quest.current(0)
        self.txt_answer.delete(0,END)
        self.txt_password.delete(0,END)
        self.txt_cpassword.delete(0,END)
         


    def register_data(self):
        if self.txt_fname.get()=="" or self.txt_email.get()=="" or self.cmb_quest.get()=="Select" or self.txt_answer.get()=="" or self.txt_password.get()=="" or self.txt_cpassword.get()=="":
            messagebox.showerror("Error","All Fields Are Required",parent=self.root)
        elif self.txt_password.get()!=self.txt_cpassword.get():
            messagebox.showerror("Error","Passwords do not match",parent=self.root)
        elif self.var_chk.get()==0:
            messagebox.showerror("Error","Please agree to our Terms & Conditions",parent=self.root)
        
                



        else:
            try:
                con=pymysql.connect(host="localhost",user="root",password="",database="customer1")
                cur=con.cursor()
                cur.execute("select * from customer where email=%s",self.txt_email.get())
                row=cur.fetchone()
                if row!=None:
                    messagebox.showerror("Error","User already exists,Use a different email ID",parent=self.root)
                else:
                    cur.execute("insert into customer (f_name,l_name,contact,email,question,answer,password) values(%s,%s,%s,%s,%s,%s,%s)",
                                    (self.txt_fname.get(),
                                    self.txt_lname.get(),
                                    self.txt_contact.get(),
                                    self.txt_email.get(),
                                    self.cmb_quest.get(),
                                    self.txt_answer.get(),
                                    self.txt_password.get()
                                    ))
                    con.commit()
                    con.close()               
                    messagebox.showinfo("Success","Registration Successful",parent=self.root)
                    self.clear()
                    


            except Exception as es:
                messagebox.showerror("Error",f"Error due to: {str(es)}",parent=self.root)




                
        


            


         




 
         

       

root=Tk()
obj=Register(root)       
root.mainloop()
from tkinter import*
from tkinter import ttk,messagebox
from PIL import Image,ImageTk
import pymysql
import random
import string





class customer:
    def __init__(self,root):
        global frame1
        self.root=root
        self.root.title("Customer Form")
        self.root.geometry("1550x800+0+0")
        self.root.config(bg="white")

        img1=Image.open(r"images\newimg1.jpg")
        img1=img1.resize((800,800))
        self.photoimg1=ImageTk.PhotoImage(img1)

        img2=Image.open(r"images\newimg2.jpg")
        img2=img2.resize((800,800))
        self.photoimg2=ImageTk.PhotoImage(img2)

    

        lblimg=Label(self.root,image=self.photoimg1,bd=4,relief=RIDGE)
        lblimg.place(x=0,y=0,width=800,height=800)


        lblimg=Label(self.root,image=self.photoimg2,bd=4,relief=RIDGE)
        lblimg.place(x=760,y=0,width=800,height=800)

         

         


        frame1=Frame(self.root,bg="lightblue")
        frame1.place(x=500,y=50,width=600,height=600)

         

        title=Label(frame1,text="Driver Page",font=("times new roman",20,"bold"),bg="lightblue",fg="black").place(x=50,y=30)


        cust_number=Label(frame1,text="Driver Number",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=50,y=100,width=200)
        self.txt_no=Label(frame1,font=("times new roman",15),bg="white")
        self.txt_no.place(x=50,y=130,width=200)

        
        

        cust_name=Label(frame1,text="Driver Name",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=300,y=100)
        self.txt_name=Entry(frame1,font=("times new roman",15),bg="white")
        self.txt_name.place(x=300,y=130,width=200)

        validate_name=self.root.register(self.checkname)
        self.txt_name.config(validate='key',validatecommand=(validate_name,'%P'))

        passengers=Label(frame1,text="Number of seats",font=("times new roman",14,"bold"),bg="lightblue",fg="black").place(x=50,y=170)
        self.cmb_quest=ttk.Combobox(frame1,font=("times new roman",13),state='readonly',justify=CENTER)
        self.cmb_quest['values']=("Select","1","2","3")
        self.cmb_quest.place(x=50,y=200,width=200)
        self.cmb_quest.current(0)

        cars=Label(frame1,text="Select Vehicle",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=300,y=170)
        self.cmb_cars=ttk.Combobox(frame1,font=("times new roman",13),state='readonly',justify=CENTER)
        self.cmb_cars['values']=("Select","Maruti WagonR","Maruti Ertiga","Honda City","Renault Duster")
        self.cmb_cars.place(x=300,y=200,width=200)
        self.cmb_cars.current(0)
         
         


        pickup=Label(frame1,text="Car Registration Number",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=50,y=240)
        self.txt_pick=Entry(frame1,font=("times new roman",13),justify=CENTER,bg="lightgray")
        self.txt_pick.place(x=50,y=270,width=200)

        validate_pick=self.root.register(self.checkname)
        self.txt_pick.config(validate='key',validatecommand=(validate_pick,'%P'))
        
         

        drop=Label(frame1,text="Select Drop Location",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=300,y=240)
        self.txt_drop=Entry(frame1,font=("times new roman",13),justify=CENTER,bg="lightgray")
        self.txt_drop.place(x=300,y=270,width=200)

        validate_drop=self.root.register(self.checkname)
        self.txt_drop.config(validate='key',validatecommand=(validate_drop,'%P'))
        
        

        
         

        pickpin=Label(frame1,text="Enter pickup pincode",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=50,y=310)
        self.txt_pickpin=Entry(frame1,font=("times new roman",15),bg="lightgray")
        self.txt_pickpin.place(x=50,y=340,width=200)

        validate_pickpin=self.root.register(self.checknumber)
        self.txt_pickpin.config(validate='key',validatecommand=(validate_pickpin,'%P'))

        droppin=Label(frame1,text="Enter drop pincode",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=300,y=310)
        self.txt_droppin=Entry(frame1,font=("times new roman",15),bg="lightgray")
        self.txt_droppin.place(x=300,y=340,width=200)

        validate_droppin=self.root.register(self.checknumber)
        self.txt_droppin.config(validate='key',validatecommand=(validate_droppin,'%P'))

        btn_can=Button(frame1,text="Cancel",cursor="hand2",command=self.cancel,font=("times new roman",15,"bold"),bg="lightgray",fg="#B00857",).place(x=325,y=404)
        self.ran_gen()
        
        btn_confirm=Button(frame1,text="Confirm",command=self.con_book,cursor="hand2",font=("times new roman",15,"bold"),bg="lightgray",fg="#B00857",).place(x=100,y=404)


    def cancel(self):
        self.root.destroy()
        import Login

    def ran_gen(self):
        c = random.randint(100000, 999999)   
        self.txt_no=Label(frame1,text=str(c),font=("times new roman",15),bg="lightblue").place(x=50,y=130,width=200)
        
        

    def cust_id(self):
        
        num=random.randint(12201, 92209)
        messagebox.showinfo("Success","Your OTP is  " + str(num))


    def con_book(self):
        if self.txt_name.get()=="" or self.txt_pick.get()=="" or self.cmb_quest.get()=="Select" or self.txt_drop.get()=="" or self.txt_pickpin.get()=="" or self.txt_droppin.get()=="":
            messagebox.showerror("Error","All Fields Are Required",parent=self.root)

        else:
            try:
                con=pymysql.connect(host="localhost",user="root",password="",database="customer1")
                cur=con.cursor()
                cur.execute("select * from carpool where cust_name=%s",self.txt_name.get())
                
                cur.execute("insert into carpool (cust_name,pickup_loc,drop_loc,pick_pin,drop_pin) values(%s,%s,%s,%s,%s)",
                                    (self.txt_name.get(),
                                    self.txt_pick.get(),
                                    self.txt_drop.get(),
                                    self.txt_pickpin.get(),
                                    self.txt_droppin
                                    ))
                con.commit()
                con.close()               
                messagebox.showinfo("Success","Booking Successful",parent=self.root)
                self.clear()
                self.cust_id()
                
                                      


            except Exception as es:
                messagebox.showerror("Error",f"Error due to: {str(es)}",parent=self.root)

    def checkname(self,name):
        if name.isalnum():
            return True
        if name=="":
            return True    
        else:
            messagebox.showerror('Invalid','Not Allowed '+name[-1]) 


    def checknumber(self,number):
        if number.isdigit():
            return True
        if len(str(number))==0:
            return True
        else:
            messagebox.showerror("Invalid","Invalid Entry")   
            return False                      

    def clear(self):
        self.txt_name.delete(0,END)
        self.txt_pick.delete(0,END)
        self.txt_drop.delete(0,END)
        self.txt_pickpin.delete(0,END)
        self.cmb_quest.current(0)
        self.cmb_cars.current(0)
        self.txt_droppin.delete(0,END)
        


root=Tk()
obj=customer(root)       
root.mainloop()        

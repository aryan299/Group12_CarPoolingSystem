from tkinter import*
from PIL import Image,ImageTk
import pymysql
from tkinter import messagebox


class Login:

    



    def __init__(self,root):
        self.root=root
        self.root.title("Login Form")
        self.root.geometry("1550x800+0+0")
        self.root.config(bg="white")

        

        img1=Image.open(r"images\download.jpg")
        img1=img1.resize((500,400))
        self.photoimg1=ImageTk.PhotoImage(img1)

        img2=Image.open(r"images\xyz.jpg")
        img2=img2.resize((800,800))
        self.photoimg2=ImageTk.PhotoImage(img2)

        img3=Image.open(r"images\abc.png")
        img3=img3.resize((800,800))
        self.photoimg3=ImageTk.PhotoImage(img3)

        lblimg=Label(self.root,image=self.photoimg3,bd=4,relief=RIDGE)
        lblimg.place(x=0,y=0,width=800,height=800)




        lblimg=Label(self.root,image=self.photoimg2,bd=4,relief=RIDGE)
        lblimg.place(x=760,y=0,width=800,height=800)


        login_frame=Frame(self.root,bg="lightgray")
        login_frame.place(x=470,y=100,width=750,height=440)

        title=Label(login_frame,text="Login Form",font=("times new roman",30,"bold"),bg="lightgray",fg="black").place(x=350,y=30)

        email=Label(login_frame,text="Username",font=("times new roman",18,"bold"),bg="lightgray",fg="black").place(x=230,y=120)
        self.txt_email=Entry(login_frame,font=("times new roman",18),bg="white",fg="black")
        self.txt_email.place(x=230,y=160,width=370,height=35)

        validate_email=self.root.register(self.checkemail)
        self.txt_email.config(validate='key',validatecommand=(validate_email,'%P'))


        pass_=Label(login_frame,text="Password",font=("times new roman",18,"bold"),bg="lightgray",fg="black").place(x=230,y=220)
        self.txt_pass=Entry(login_frame,show="*",font=("times new roman",18),bg="white",fg="black")
        self.txt_pass.place(x=230,y=260,width=370,height=35)


        btn_reg=Button(login_frame,text="Register Now",cursor="hand2",command=self.register_win,font=("times new roman",12,"bold"),relief=FLAT,bg="lightgray",fg="#B00857",).place(x=225,y=294)

        btn_login=Button(login_frame,text="Login as Customer",command=self.login,font=("times new roman",20,"bold"),bg="#B00857",fg="lightgray",cursor="hand2").place(x=230,y=354,width=240,height=40)

        btn_login=Button(login_frame,text="Login as Driver",command=self.log_driver,font=("times new roman",20,"bold"),bg="#B00857",fg="lightgray",cursor="hand2").place(x=500,y=354,width=200,height=40)

        

        self.lblimg=Label(self.root,image=self.photoimg1,bd=0,relief=FLAT,bg="white")
        self.lblimg.place(x=310,y=120,width=350,height=400)
    
    def register_win(self):
        self.root.destroy()
        import register

    def log_driver(self):
        if self.txt_email.get()=="" or self.txt_pass.get()=="":
            messagebox.showerror("Error","All fields are required",parent=self.root)
        else:
            try:
                con=pymysql.connect(host="localhost",user="root",password="",database="customer1")
                cur=con.cursor()
                cur.execute("select * from customer where email=%s and password=%s",(self.txt_email.get(),self.txt_pass.get()))
                row=cur.fetchone()
                if row==None:
                    messagebox.showerror("Error","Invalid username or incorrect password",parent=self.root)
                    
                else:
                    messagebox.showinfo("Success","Welcome!",parent=self.root)
                    self.root.destroy()
                    import driver
                
                con.close()    
                

            except Exception as es:
                messagebox.showerror("Error",f"Error Due To: {str(es)}",parent=self.root)


    def checkemail(self,email):
        if len(email)>7:
            if re.match("^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$",email):
                return True
            else:
                messagebox.showwarning("Alert","Invalid Email")   
                return False 
           

    def login(self):
        if self.txt_email.get()=="" or self.txt_pass.get()=="":
            messagebox.showerror("Error","All fields are required",parent=self.root)
        else:
            try:
                con=pymysql.connect(host="localhost",user="root",password="",database="customer1")
                cur=con.cursor()
                cur.execute("select * from customer where email=%s and password=%s",(self.txt_email.get(),self.txt_pass.get()))
                row=cur.fetchone()
                if row==None:
                    messagebox.showerror("Error","Invalid username or incorrect password",parent=self.root)
                    
                else:
                    messagebox.showinfo("Success","Welcome!",parent=self.root)
                    self.root.destroy()
                    import homepage
                
                con.close()    
                

            except Exception as es:
                messagebox.showerror("Error",f"Error Due To: {str(es)}",parent=self.root)
    

        
    

    
    






































root=Tk()
obj=Login(root)     
root.mainloop()

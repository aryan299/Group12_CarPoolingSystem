from tkinter import*
from tkinter import ttk,messagebox
from PIL import Image,ImageTk
import pymysql
import random
import string





class customer:
    def __init__(self,root):
        global frame1
        self.root=root
        self.root.title("Customer Form")
        self.root.geometry("1550x800+0+0")
        self.root.config(bg="white")

        img1=Image.open(r"images\newimg1.jpg")
        img1=img1.resize((800,800))
        self.photoimg1=ImageTk.PhotoImage(img1)

        img2=Image.open(r"images\newimg2.jpg")
        img2=img2.resize((800,800))
        self.photoimg2=ImageTk.PhotoImage(img2)

    

        lblimg=Label(self.root,image=self.photoimg1,bd=4,relief=RIDGE)
        lblimg.place(x=0,y=0,width=800,height=800)


        lblimg=Label(self.root,image=self.photoimg2,bd=4,relief=RIDGE)
        lblimg.place(x=760,y=0,width=800,height=800)

         

         


        frame1=Frame(self.root,bg="lightblue")
        frame1.place(x=500,y=50,width=600,height=600)

         

        title=Label(frame1,text="Car Pooling Page",font=("times new roman",20,"bold"),bg="lightblue",fg="black").place(x=50,y=30)


        cust_number=Label(frame1,text="Customer Number",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=50,y=100,width=200)
        global c
        c = random.randint(100000, 999999)   
        self.txt_no=Entry(frame1,font=("times new roman",15))
        self.txt_no.place(x=50,y=130,width=200)
        

        
        

        cust_name=Label(frame1,text="Customer Name",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=300,y=100)
        

        
        
        pickup=Label(frame1,text="Select Pickup Location",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=50,y=240)
        self.pick=Entry(frame1,font=("times new roman",14,"bold"),bg="lightblue",fg="black")
        self.pick.place(x=50,y=270,width=200)

        drop=Label(frame1,text="Select Drop Location",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=300,y=240)
        self.drop=Entry(frame1,font=("times new roman",14,"bold"),bg="lightblue",fg="black")
        self.drop.place(x=300,y=270,width=200)
        

        self.txt_name=Entry(frame1,font=("times new roman",14,"bold"),bg="lightblue",fg="black")
        self.txt_name.place(x=300,y=130,width=200)
        
        
        

        
         

        pickpin=Label(frame1,text="Enter pickup pincode",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=50,y=310)
        self.txt_pickpin=Entry(frame1,font=("times new roman",15),bg="lightblue")
        self.txt_pickpin.place(x=50,y=340,width=200)

        

        droppin=Label(frame1,text="Enter drop pincode",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=300,y=310)
        self.txt_droppin=Entry(frame1,font=("times new roman",15),bg="lightblue")
        self.txt_droppin.place(x=300,y=340,width=200)

        

        btn_can=Button(frame1,text="Cancel",cursor="hand2",command=self.cancel,font=("times new roman",15,"bold"),bg="lightgray",fg="#B00857",).place(x=325,y=404)
        
        
        btn_confirm=Button(frame1,text="Check Details",command=self.checkdet,cursor="hand2",font=("times new roman",15,"bold"),bg="lightgray",fg="#B00857",).place(x=100,y=404)

    def cancel(self):
        self.root.destroy()
        import homepage


    def checkdet(self):
        if self.txt_no.get()=="":
            messagebox.showerror("Error","Enter Customer Number",parent=self.root)
        else:
            try:
                cc_no=self.txt_no.get()
                con=pymysql.connect(host="localhost",user="root",password="",database="customer1")
                cur=con.cursor()
                
                cur.execute("select * from carpool where custno=('"+cc_no+"')")
                
                cust_name=cur.fetchall()
                for row in cust_name:
                    self.txt_name.insert(0, row[1])
                    self.pick.insert(0, row[2])
                    self.drop.insert(0, row[3])
                    self.txt_pickpin.insert(0, row[4])
                    self.txt_droppin.insert(0, row[5])
                    self.txt_no.focus_get()
                    
        
                    
                    
                    

                
                
                
                
                con.close()    
                

            except Exception as es:
                messagebox.showerror("Error",f"Error Due To: {str(es)}",parent=self.root)









root=Tk()
obj=customer(root)       
root.mainloop()        

from tkinter import*
from tkinter import ttk,messagebox
from PIL import Image,ImageTk
import pymysql
import sys
import random
import string


class payment:
    def __init__(self,root):
        global frame1
        self.root=root
        self.root.title("Registration Form")
        self.root.geometry("600x600+500+50")
        self.root.config(bg="white")

        frame1=Frame(self.root,bg="lightblue")
        frame1.place(x=0,y=0,width=600,height=600)

        
        reference=Label(frame1,text="Receipt Number",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=80,y=100)

        name=Label(frame1,text="Enter Your Name",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=50,y=170)
        self.txt_name=Entry(frame1,font=("times new roman",15),bg="white")
        self.txt_name.place(x=50,y=200,width=200)

        validate_name=self.root.register(self.checkname)
        self.txt_name.config(validate='key',validatecommand=(validate_name,'%P'))



        car_no=Label(frame1,text="Car Number",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=300,y=170)
        
        

        amount=Label(frame1,text="Amount",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=50,y=240)
        
        payment_cmb=Label(frame1,text="Select Payment Method",font=("times new roman",14,"bold"),bg="lightblue",fg="black").place(x=300,y=240)
        self.cmb_quest=ttk.Combobox(frame1,font=("times new roman",13),state='readonly',justify=CENTER)
        self.cmb_quest['values']=("Select","Card","Cash")
        self.cmb_quest.place(x=300,y=270,width=200)
        self.cmb_quest.current(0)

        
        

        
        
          


        self.ccno=Label(frame1,text="Credit Card Number",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=50,y=310)
        self.txt_ccno=Entry(frame1,font=("times new roman",15),bg="white")
        self.txt_ccno.place(x=50,y=340,width=200)

        validate_ccno=self.root.register(self.checknumber)
        self.txt_ccno.config(validate='key',validatecommand=(validate_ccno,'%P'))

        self.cvv=Label(frame1,text="Enter CVV",font=("times new roman",15,"bold"),bg="lightblue",fg="black").place(x=300,y=310)
        self.txt_cvv=Entry(frame1,font=("times new roman",15),bg="white")
        self.txt_cvv.place(x=300,y=340,width=200)


        global c
        c = random.randint(100000, 999999)
        self.reference2=Label(frame1,text=str(c),font=("times new roman",15,"bold"),bg="lightblue",fg="black")
        self.reference2.place(x=50,y=130,width=200)

        

        validate_cvv=self.root.register(self.checkcvv)
        self.txt_cvv.config(validate='key',validatecommand=(validate_cvv,'%P'))

        btn_pay=Button(frame1,text="Pay",command=self.pay_but,font=("times new roman",20,"bold"),bg="#B00857",fg="lightgray",cursor="hand2").place(x=70,y=414,width=150,height=40)

        btn_cancel=Button(frame1,text="Cancel",command=self.cancel_but,font=("times new roman",20,"bold"),bg="#B00857",fg="lightgray",cursor="hand2").place(x=320,y=414,width=150,height=40)
        
        btn_cash=Button(frame1,text="Pay with Cash",command=self.hide,font=("times new roman",20,"bold"),bg="#B00857",fg="lightgray",cursor="hand2").place(x=160,y=494,width=200,height=40)
        

    
    def hide(self):
        if self.cmb_quest.get()=="Cash":
            self.txt_ccno.place_forget()
            self.txt_cvv.place_forget()
            
            messagebox.showinfo("Cash Selected","Please pay the driver with cash")
            
            
    def ran_gen(self):
        con=pymysql.connect(host="localhost",user="root",password="",database="customer1")
        cur=con.cursor()
        cur.execute("select * from new where refer=%s",self.reference2.cget('text'))
                
        cur.execute("insert into new (refer) values(%s)",
                            (self.reference2.cget('text'),
                            
                            ))
        con.commit()
        con.close()               
        
                
        
        
        d = random.randint(600, 800)
        self.txt_amount=Label(frame1,text="Rs " + str(d),font=("times new roman",15),bg="white").place(x=50,y=270,width=200)
        mh = random.randint(10, 99)
        ab = random.randint(1000, 9999)
        
        self.txt_car=Label(frame1,text="MH "+ str(mh) + " GH " + str(ab),font=("times new roman",15),bg="white").place(x=300,y=200,width=200)



    def checknumber(self,number):
        if number.isdigit():
            return True
        if len(str(number))==0:
            return True
        else:
            messagebox.showerror("Invalid","Invalid Entry")
            return False   

    def checkcvv(self,number):
        if len(str(number))<4:
            if number.isdigit():
                return True
            if len(str(number))==0:
                return True
            else:
                messagebox.showerror("Invalid","Invalid Entry")   
                return False           
        else:
            messagebox.showerror("Invalid","CVV incorrect")


   


    
    def cancel_but(self):
        self.root.destroy()
        import homepage

    def pay_but(self):
        if self.txt_name.get()=="" or self.cmb_quest.get()=="Select":
            messagebox.showerror("Error","Please fill all fields")   
        else:
            messagebox.showinfo("Success","Payment Successful")     


    def checkname(self,name):
        if name.isalnum():
            return True
        if name=="":
            return True    
        else:
            messagebox.showerror('Invalid','Not Allowed '+name[-1])             














root=Tk()
obj=payment(root)   
obj.ran_gen() 
root.mainloop()
